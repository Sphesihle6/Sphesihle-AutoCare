/* ===================================== 
   SPHESIHLE'S AUTOCARE 
   ===================================== */ 

// 1. Welcome message 

document.addEventListener("DOMContentLoaded", function () { 
    console.log("Welcome to Sphesihle's AutoCare!"); 

    // Display current year in footer 

    const year = document.getElementById("year"); 
    if (year) { 
        year.textContent = new Date().getFullYear(); 

    } 

 

    // 2. Highlight the current navigation page 

    const currentPage = window.location.pathname.split("/").pop(); 
    document.querySelectorAll("nav a").forEach(function (link) { 
        const linkPage = link.getAttribute("href"); 

        if (linkPage === currentPage) { 
            link.classList.add("active"); 

        } 

    }); 

}); 

// 3. Enquiry form validation 

const enquiryForm = document.getElementById("EnquiryForm"); 

if (enquiryForm) { 
    enquiryForm.addEventListener("submit", function (event) { 

        event.preventDefault(); 

        const name = document.getElementById("name").value.trim(); 
        const email = document.getElementById("email").value.trim(); 
        const phone = document.getElementById("phone").value.trim(); 
        const service = document.getElementById("service").value; 

        if (name === "" || email === "" || 
            phone === "" || service === "") { 
            alert("Please complete all required fields."); 
            return; 

        } 


    // Check email format 

        const emailPattern = 
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 

        if (!emailPattern.test(email)) { 
            alert("Please enter a valid email address."); 
            return; 

        } 

        alert( 
            "Thank you, " + name + 
            "! Your enquiry has been received." 

        ); 
        enquiryForm.reset(); 

    }); 

}  

// 4. Contact form validation 

const contactForm = document.getElementById("contactForm"); 

if (contactForm) { 

    contactForm.addEventListener("submit", function (event) { 
        event.preventDefault(); 

        const name = document.getElementById("contactName").value.trim(); 
        const email = document.getElementById("contactEmail").value.trim(); 
        const message = document.getElementById("message").value.trim(); 

        if (name === "" || email === "" || message === "") { 
            alert("Please fill in all the required fields."); 
            return; 

        } 

        alert("Thank you " + name + "! Your message has been received."); 
        contactForm.reset(); 

    }); 

} 

// 5. Back to top button 

const backToTop = document.getElementById("backToTop"); 

if (backToTop) { 

    backToTop.addEventListener("click", function () { 
        window.scrollTo({ 
            top: 0, 
            behavior: "smooth" 

        }); 

    }); 

} 

// 6. Confirm booking or service enquiry 

function confirmBooking() { 

    alert("Thank you for choosing Sphesihle's AutoCare!"); 

} 

// 7. Display current date 

function displayDate() { 
    const today = new Date(); 
    return today.toDateString(); 

} 