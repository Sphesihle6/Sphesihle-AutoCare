#Part 2 improvements 

1. From the feedback I got from my lecture I was supposed to link my external css file with my html/web Pages using this tag on all my web pages
<link rel="stylesheet" type="text/css" href="css/style1.css">

2. For the Final POE I am required to create a website using HTML, style the web pages using external css then add an HTML form so that I can be able to do form validation using javaScript

3. I am also planning add date and time update on all the footer of web pages 


4. I am planning to insert the map container

5. I changed the footer's alignment to center 

6. I am going to add a SEO in all my web pages

7. I'm going to create a gallery page 






References
https://www.w3schools.com/html/html_iframe.asp
https://www.w3schools.com/html/html_buttons.asp
https://www.w3schools.com/html/html_css.asp
https://www.w3schools.com/html/html_comments.asp


